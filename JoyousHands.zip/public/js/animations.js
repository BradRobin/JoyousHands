gsap.from("h1", { duration: 1, x: -100, opacity: 0 });
